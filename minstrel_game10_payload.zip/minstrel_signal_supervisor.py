#!/usr/bin/env python3
"""Signal-safe process-group supervisor. Run one child in foreground; no orphan on cancellation."""
import os, signal, subprocess, time

class Interrupted(Exception):
    def __init__(self, signum): self.signum=signum

def supervise(command, *, cwd=None, log_path=None, timeout=65, grace=3, on_started=None):
    child=None
    previous={}
    received=[]
    def handler(signum, frame):
        received.append(signum)
        if child is not None and child.poll() is None:
            try: os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError: pass
        raise Interrupted(signum)
    for sig in (signal.SIGTERM,signal.SIGINT):
        previous[sig]=signal.getsignal(sig); signal.signal(sig,handler)
    started=time.monotonic(); timed_out=False; exit_code=None; interrupted=None
    try:
        with open(log_path,'ab',buffering=0) if log_path else open(os.devnull,'wb') as log:
            child=subprocess.Popen(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            if on_started: on_started(child.pid)
            try: exit_code=child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out=True
                try: os.killpg(child.pid,signal.SIGTERM)
                except ProcessLookupError: pass
                try: exit_code=child.wait(timeout=grace)
                except subprocess.TimeoutExpired:
                    try: os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError: pass
                    exit_code=child.wait()
    except Interrupted as e:
        interrupted=e.signum
    finally:
        if child is not None:
            # Kill the group even if the immediate child exited, in case it spawned descendants.
            if interrupted is not None or timed_out:
                try: os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError: pass
            try: child.wait(timeout=grace)
            except subprocess.TimeoutExpired:
                try: os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError: pass
                child.wait()
        for sig, old in previous.items(): signal.signal(sig,old)
    return {'exit_code':exit_code,'timeout':timed_out,'interrupted_signal':interrupted,'elapsed_seconds':round(time.monotonic()-started,2)}
