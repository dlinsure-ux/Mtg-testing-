#!/usr/bin/env python3
import json, os, pathlib, sys, time
from minstrel_signal_supervisor import supervise
ROOT=pathlib.Path(__file__).resolve().parent
SERIES=ROOT/'series'
FORGE=pathlib.Path(os.environ['FORGE_DIR']).resolve()
JAR=next(FORGE.glob('forge-gui-desktop-2.0.14-jar-with-dependencies.jar'),None)
if not JAR: raise SystemExit('Forge 2.0.14 jar missing in '+str(FORGE))
def valid(i):
    p=SERIES/f'game_{i:02d}'/'game_01_result.json'
    if not p.exists():return None
    try:
        j=json.loads(p.read_text())
        if j.get('valid') is True and j.get('winner') and isinstance(j.get('ending_turn'),int) and j['ending_turn']>0:
            return j
    except (ValueError,OSError,TypeError): pass
    return None
prior=[i for i in range(1,11) if valid(i)]
if prior!=list(range(1,10)):
    raise SystemExit('Refusing run: expected exactly nine valid previous checkpoints, found '+str(prior))
i=10
d=SERIES/'game_10';d.mkdir(exist_ok=True)
cp=str(ROOT/'pilot')+os.pathsep+str(JAR)
decks=[ROOT/'decks'/x for x in ['wandering_minstrel_canonical.dck','shroofus.dck','betor.dck','chiss_goria.dck']]
cmd=['xvfb-run','-a','java','-Xmx3g','-cp',cp,'MinstrelNeutralProbe',*[str(x) for x in decks],str(d),'1',str(d/'child.log')]
print('Running game 10 only with v0.5 compiled pilot; Forge directory:',FORGE,flush=True)
r=supervise(cmd,cwd=FORGE,log_path=d/'console.log',timeout=1200,grace=10)
j=valid(10)
status={**r,'game':10,'valid':bool(j),'winner':j.get('winner') if j else None,'ending_turn':j.get('ending_turn') if j else None}
tmp=d/'supervisor_status.json.tmp';tmp.write_text(json.dumps(status,indent=2));os.replace(tmp,d/'supervisor_status.json')
results=[{'game':i,'winner':valid(i)['winner'],'ending_turn':valid(i)['ending_turn']} for i in range(1,11) if valid(i)]
manifest={'series':'MINSTREL_V0_5_DIAGNOSTIC','completed':len(results),'target':10,'results':results,'next_game':next((i for i in range(1,11) if not valid(i)),None)}
tmp=SERIES/'series_manifest.json.tmp';tmp.write_text(json.dumps(manifest,indent=2));os.replace(tmp,SERIES/'series_manifest.json')
print('GAME_10_STATUS',json.dumps(status),flush=True)
print('SERIES_PROGRESS',len(results),'/10',flush=True)
if not j:raise SystemExit(1)
