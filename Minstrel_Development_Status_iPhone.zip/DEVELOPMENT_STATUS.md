# Wandering Minstrel — experimental development baseline

Source: MINSTREL_GAME7_DEFENSE_LOGGING_FIX_2026-10-08.tar.gz, reconstructed pilot. NOT original v0.7.

- Forge engine target: 2.0.14.
- Reported verified record: 4 wins / 4 losses after Game 8.
- Latest completed Game 8: loss to Shroofus on turn 15.
- Defensive telemetry remains incomplete/unverified in Game 8 output.
- Pact handling conservatively fails closed until upkeep payment can be verified.
- Canonical 100-card deck must not change without explicit user authorization.
- Do not promote this experimental branch to main without reproducible compilation and real game testing.

## Next steps
1. Verify source compilation against the Forge 2.0.14 dependencies.
2. Add complete per-decision combat/Pact logs and retain game checkpoints.
3. Run bounded real Forge games; inspect logs and outcomes.
4. Review changes before merging to main.

Do not upload full Forge runtime, archives or credentials to the public repository.
